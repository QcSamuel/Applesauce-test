# Applesauce (ios-host) — HyperHLE core updated to KlugKlugTG/HyperHLE-Fork trunk

This zip contains only the files that changed when merging
`KlugKlugTG/HyperHLE-Fork`'s `trunk` branch (565 commits) into
`0xjohnnydev/Applesauce`'s `ios-host` branch (45 commits since the
shared base), with all conflicts resolved.

Base commit merged from (ios-host): e8e9d674a84903b14da0d9deb1dbe4f1dc735624
Base commit merged in (fork trunk): 645799a8184853e819816a460cff8e4fa2b06fd9

## What's in this zip
347 changed files, matching their original repo-relative paths.
Extract this zip over a checkout of `0xjohnnydev/Applesauce` at
`ios-host` (or your fork of it) and it will overwrite/add exactly the
files that changed.

**Not included** (too large / not relevant to iOS):
- `vendor/` (third-party submodule content, untouched)
- `android/app/jniLibs/**/*.so` (new Android ANGLE binaries — ~7MB each,
  irrelevant to the iOS build; pull these separately from the fork's
  `android/app/jniLibs/` if you also build for Android)

## Files the merge DELETES
These existed on `ios-host` before the merge and are gone afterward —
delete them manually after applying this zip, since a zip upload can't
express a deletion:
- `.github/workflows/run_ipa.yml`
- `android/app/src/main/java/org/libsdl/app/` (old single-file version;
  replaced by a directory of files, which ARE included in this zip)
- `src/licenses.rs`

## How to apply via GitHub's mobile web upload
1. On your fork, create a new branch (e.g. `update-hyperhle-core`) from `ios-host`.
2. On that branch, go to each changed file's path and use "Add file →
   Upload files", dragging in the corresponding file(s) from this zip
   at the matching path. GitHub's web uploader preserves folder
   structure if you drag a folder, so uploading whole subtrees
   (e.g. everything under `src/frameworks/opengles/`) at once works.
3. Manually delete the three files listed above.
4. Commit to the branch, then open a PR into `ios-host` (or push
   directly if you're working on your own fork).
5. If `.github/workflows/HyperHLE_release.yml` triggers on push, the
   iOS build will run automatically and produce artifacts you can
   download from the Actions tab.

## Key resolutions worth knowing about
- `src/frameworks/opengles/eagl.rs` had the deepest conflicts (24
  hunks) — the ES2 shader presenter, readback path and present-mode
  selection were taken wholesale from trunk (better driver-quirk
  handling, caching), while iOS-specific pieces were preserved:
  the `FRAMEBUFFER_BINDING_OES` host-framebuffer probe, the
  rotation-matrix-into-texcoords logic for iPad autorotation, and
  the `--ios-es2-direct-present` fast path used by The Sims Medieval.
- `src/window.rs`: adopted trunk's proper background/foreground
  lifecycle event handling (`AppDidEnterBackground` /
  `AppWillEnterForeground` / `AppDidBecomeActive`) in place of HEAD's
  older iOS-bypass + blocking `high_priority_event` mechanism, after
  confirming via `git log` that the old mechanism was already known-
  buggy (it could drop events) and the iOS bypass predated that fix.
- Two dead-code paths present in HEAD but never called anywhere were
  dropped during the merge rather than resurrected: `visitWebsite` in
  `app_picker.rs` and the `CopyrightInfoStuff` copyright-info panel
  (also `app_picker.rs`), plus an `IOS_PRESENT_PIXELS` readback in
  `eagl.rs` that read pixels back to CPU only to re-upload them
  unchanged and was never consumed anywhere.

This merge was NOT compiled/tested — no Rust toolchain or iOS SDK
was available in the environment it was produced in. Build and test
before relying on it.
